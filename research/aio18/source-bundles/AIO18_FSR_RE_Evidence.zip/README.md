# AIO18 FSR reverse-engineering evidence

Start with **AIO18_FSR_RE.md**. `verification.json` records the validation actually run on the original upload. This is static evidence, not a GPU test, performance benchmark, or compatibility certification.

## Contents

`evidence/manifest.json` hashes the original archive and all 25 files. `pe_inventory.json` inventories PE versions, imports, delay imports, exports, and CodeView records. The two `*.identity.json` files establish AMD PDB/DLL matches. `amd_fg_struct_layouts.json` contains 20 extracted structure layouts (122 fields). `landmarks.json` gives 50 specific instruction addresses, bytes, module hashes, and labels. There are 39 disassembly excerpts; selected symbols, targeted string references, vtable records, and UI enum flags provide cross-checks.

**No original DLLs or PDBs are redistributed.** Supply your own matching archive to reproduce. Long embedded shader/string dumps have deliberately been omitted. Full raw disassembly can be regenerated locally.

## Reproduce the static checks

The scripts use Python's standard library. Extraction additionally needs system libarchive; disassembly needs GNU objdump. These commands are intended for Linux/WSL. Do not execute the uploaded DLLs as part of this workflow.

```bash
mkdir -p work
python scripts/extract_archive.py /path/to/SkyrimUpscalerAIOBuild18-Hotfix1.7z work/extracted > work/manifest.json
python scripts/verify_evidence.py work/extracted \
  --archive /path/to/SkyrimUpscalerAIOBuild18-Hotfix1.7z \
  --output work/verification.json
```

The archive's filename may differ; verification uses byte size and SHA-256. Use a fresh extraction directory. The utilities are purpose-built analysis helpers for this matching build, not hardened parsers for hostile arbitrary archives or corrupt PE/PDB files.

## Regenerate a disassembly excerpt

```bash
objdump -d -M intel --no-show-raw-insn \
  work/extracted/UpscalerBasePlugin/PDPerfPlugin.dll > work/pd.asm

python scripts/disasm_index.py \
  --dll work/extracted/UpscalerBasePlugin/PDPerfPlugin.dll \
  --asm work/pd.asm \
  --strings evidence/PDPerfPlugin_selected_strings.json \
  dump 0xEF230 > work/pd_fsr_fg_evaluate.asm
```

For AMD functions, pass its matching DLL/disassembly and `--symbols evidence/amd_fg_selected_symbols.json`. Other operations are `xrefs RVA`, `overview RVA`, `strings REGEX`, and `vtables REGEX`. The left column is always an RVA. Instruction operands keep objdump's preferred virtual addresses. Recovered function ranges follow chained unwind metadata; leaf-function fallback ranges are approximate. Prefer explicit `dump START END` for leaf snippets.

PDB identities/symbols can be regenerated with:

```bash
python scripts/pdb_index.py \
  work/extracted/UpscalerBasePlugin/amd_fidelityfx_framegeneration_dx12.pdb \
  work/extracted/UpscalerBasePlugin/amd_fidelityfx_framegeneration_dx12.dll \
  work/amd_fg
```

The verifier reparses stored PDB type indices and checks names, sizes, and every stored field against the matching PDB. Those type indices are not portable to a different PDB.

## Runtime work not done here

The report's breakpoint plan is proposed follow-up work. No Windows debugger traces, GPU captures, Skyrim engine RVAs, ENB/Scaleform ordering validation, supported-provider confirmation on any user's GPU, or output quality/performance results were collected in this pass.
